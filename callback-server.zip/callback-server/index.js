const express = require("express");
const app = express();
app.use(express.json());

// In-memory store of confirmed payments
// { [checkout_id]: "success" | "failed" }
const payments = {};

// -------------------------------------------------------
// POST /callback
// Hashback calls this URL after the customer pays or fails
// -------------------------------------------------------
app.post("/callback", (req, res) => {
  console.log("Hashback callback received:", JSON.stringify(req.body));

  const body = req.body;

  // Hashback sends different shapes — handle both
  const checkoutId =
    body.CheckoutRequestID ||
    body.checkout_request_id ||
    body.id ||
    body.checkout_id;

  const resultCode =
    body.ResultCode ??
    body.result_code ??
    body.status;

  if (!checkoutId) {
    return res.status(400).json({ error: "Missing checkout ID" });
  }

  // ResultCode "0" or status "success" means paid
  if (resultCode === 0 || resultCode === "0" || resultCode === "success") {
    payments[checkoutId] = "success";
    console.log("Payment SUCCESS for:", checkoutId);
  } else {
    payments[checkoutId] = "failed";
    console.log("Payment FAILED for:", checkoutId, "code:", resultCode);
  }

  res.json({ received: true });
});

// -------------------------------------------------------
// GET /callback?checkout_id=xxxx
// The payment page polls this to check if payment is done
// -------------------------------------------------------
app.get("/callback", (req, res) => {
  const checkoutId = req.query.checkout_id;

  if (!checkoutId) {
    return res.status(400).json({ error: "Missing checkout_id" });
  }

  const status = payments[checkoutId] || "pending";
  res.json({ status });
});

// Health check
app.get("/", (req, res) => {
  res.json({ ok: true, message: "Two Term Community 2027 — callback server running" });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
